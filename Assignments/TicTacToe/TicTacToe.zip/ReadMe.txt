This is a simple python program written for my sdev140 class. 
It is a Tic Tac Toe game ment to showcase the programming skills i learned over the semester.
I used PyQt5 to create two UI windows one being the tic tac toe board 
with buttons that can be pused to ake an x or O pop up dpending on whos turn it is.
After someone has won the scoreboard will pop up showing the current score and you can either press "OK"
to start a new game or "cancel" to exit the entire program. 