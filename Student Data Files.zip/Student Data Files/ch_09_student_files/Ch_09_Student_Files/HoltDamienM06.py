#import
from breezypythongui import EasyFrame
#GUI
class TempCalc(EasyFrame):
    def __init__(self):
        EasyFrame.__init__(self, title="Temperature Calculator")

        self.addLabel(text="Input Temperature:", row = 0, column=0,)
        self.inputBox = self.addTextField(text = "", row = 0, column= 1)

        self.addLabel(text="Output Temperature:", row = 1, column=0)
        self.outputBox = self.addTextField(text = "", row = 1, column= 1)

        self.addLabel(text="Temp Type:", row = 2, column=0, columnspan= 2)
        self.addButton(text="Farenheit", row=3, column= 0, command= self.F)

        self.addButton(text="Celsius", row=3, column= 1, command= self.C)


        def F(self):
            TempF = self.inputBox.getText()
            CConvert = ((TempF - 32) * (5/9))
            self.outputBox.setText(CConvert)



