# Write a Python GUI program
# using tkinter module
# to input Income and Dependents in Entry widgets
# that are in text boxes and computes total Tax
# on a button click event
#
# This is in your Chapter 8 PowerPoint (slide 6). 

import tkinter as tk


def main():
    window= tk.Tk()
    window.title("Tax Calculator")
    window.geometry("375x200")
    
    # create a label with text Enter Miles
    label1 = tk.Label(window, text="Gross Income:")
    
    # create a label with text Kilometers:
    label2 = tk.Label(window, text="Dependents:")

    # place label1 in window at position x,y 
    label1.place(x=50,y=30)

    # create an Entry widget (text box) 
    
    txtIncome = tk.Entry(window, width=12)

    # Dependents
    txtDependents = tk.Entry(window, width=12)
    

    # place Income in window at position x,y 
    txtIncome.place(x=200,y=35)

    # place Dependents
    txtDependents.place(x=200,y=75)
        

    # place label2 in window at position x,y 
    label2.place(x=50,y=75)
    
    # create a label3 with empty text:
    label3 = tk.Label(window, text="Total tax:")

    # place label3 in window at position x,y 
    label3.place(x=50,y=110)

    # create a label3 with empty text:
    label4 = tk.Label(window, text=" ")

    # place label3 in window at position x,y 
    label4.place(x=200,y=110)

         
    def btn1_click():
        TotalTax = round((float(txtIncome.get()) * .35) - (int(txtDependents.get()) * 1000.00))
        label4.configure(text = str(TotalTax))
        
    def btn2_click():
        window.destroy()
        

    # create a button with text Button 1
    btn1 = tk.Button(window, text="Compute", command=btn1_click)
    # place this button in window at position x,y 
    btn1.place(x=90,y=150)

    btn2 = tk.Button(window, text="Exit", command=btn2_click)
    btn2.place(x=250,y=150)
    
    window.mainloop()
    

main()
